//
//  WorkoutExercise.swift
//  Workout Manager
//
//  Created by Jason Voll on 2016-10-30.
//  Copyright © 2016 Jason Learning Co. All rights reserved.
//

import Foundation
import CoreData


class WorkoutExercise: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
